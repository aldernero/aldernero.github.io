---
                title: "insidemordecai.com"
                tags: [パーソナルサイト]
                externalUrl: "https://insidemordecai.com"
                weight: 11
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

