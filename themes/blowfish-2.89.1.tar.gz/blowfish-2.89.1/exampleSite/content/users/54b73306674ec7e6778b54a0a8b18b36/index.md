---
                title: "Handbook on Teaching Empirical Software Engineering: Online Materials"
                tags: [Book,Academia]
                externalUrl: "https://www.emse.education"
                weight: 82
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
