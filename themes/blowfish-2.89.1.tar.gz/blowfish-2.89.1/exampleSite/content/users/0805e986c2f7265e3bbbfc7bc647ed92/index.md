---
                title: "Chill-Try"
                tags: [Technology Blog,Personal site,Blog]
                externalUrl: "https://ctry.tech/"
                weight: 93
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
