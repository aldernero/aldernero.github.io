---
                title: "Chill-Try"
                tags: [Blog tecnologico, Sito personale, Blog]
                externalUrl: "https://ctry.tech/"
                weight: 93
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

