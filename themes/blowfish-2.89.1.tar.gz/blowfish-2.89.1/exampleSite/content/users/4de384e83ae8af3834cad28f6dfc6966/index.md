---
                title: "Ignacio Conde"
                tags: [Personal Site,Portfolio Site,Software Developer,Videogame Developer]
                externalUrl: "http://www.ignaciomconde.com/"
                weight: 68
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
