---
                title: "asterisk.lol"
                tags: [ブログ, パーソナルサイト]
                externalUrl: "https://asterisk.lol"
                weight: 58
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

