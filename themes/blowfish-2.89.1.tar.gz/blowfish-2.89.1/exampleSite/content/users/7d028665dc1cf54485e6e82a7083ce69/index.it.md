---
                title: "karlukle.site"
                tags: [Blog personale]
                externalUrl: "https://karlukle.site"
                weight: 63
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

