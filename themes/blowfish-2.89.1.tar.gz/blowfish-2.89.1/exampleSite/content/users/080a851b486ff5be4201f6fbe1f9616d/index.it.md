---
                title: "merox.dev"
                tags: [Sito personale, Blog, Documentazione, Cv]
                externalUrl: "https://merox.dev"
                weight: 84
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

