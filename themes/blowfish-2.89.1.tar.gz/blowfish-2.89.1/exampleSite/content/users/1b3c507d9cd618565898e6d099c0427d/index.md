---
                title: "mayer.life"
                tags: [Personal site]
                externalUrl: "https://mayer.life"
                weight: 43
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
