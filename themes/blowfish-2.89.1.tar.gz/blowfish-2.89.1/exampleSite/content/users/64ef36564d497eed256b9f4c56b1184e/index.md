---
                title: "brendanwallace.github.io"
                tags: [Personal site]
                externalUrl: "https://brendanwallace.github.io"
                weight: 5
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
