---
                title: "Middle of Nowhere"
                tags: [パーソナルサイト, ブログ]
                externalUrl: "https://blog.wtcx.dev/"
                weight: 72
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

