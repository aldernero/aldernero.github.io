---
                title: "micheledinelli.github.io"
                tags: [Personal Site,Portfolio Site,Academia]
                externalUrl: "https://micheledinelli.github.io"
                weight: 75
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
