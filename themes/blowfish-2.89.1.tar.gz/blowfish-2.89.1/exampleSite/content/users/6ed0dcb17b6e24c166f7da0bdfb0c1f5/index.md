---
                title: "technicat.com"
                tags: [Company site]
                externalUrl: "https://technicat.com/"
                weight: 24
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
