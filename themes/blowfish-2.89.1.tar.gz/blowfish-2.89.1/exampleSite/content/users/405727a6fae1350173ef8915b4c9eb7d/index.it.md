---
                title: "FEEC/UNICAMP IA382 - Seminar in Computer Engineering"
                tags: [Seminari, Classe]
                externalUrl: "https://feec-seminar-comp-eng.github.io/"
                weight: 100
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

