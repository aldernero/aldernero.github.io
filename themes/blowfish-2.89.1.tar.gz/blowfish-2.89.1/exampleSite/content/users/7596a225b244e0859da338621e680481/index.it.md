---
                title: "p3rception.github.io"
                tags: [Sito personale, Blog]
                externalUrl: "https://p3rception.github.io/"
                weight: 81
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

