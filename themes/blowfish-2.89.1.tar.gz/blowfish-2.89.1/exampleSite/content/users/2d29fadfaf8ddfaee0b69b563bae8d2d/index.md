---
                title: "Hudson McNamara"
                tags: [Personal Site,Blog]
                externalUrl: "https://hudsonmcnamara.com"
                weight: 94
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
