---
                title: "Hudson McNamara"
                tags: [パーソナルサイト, ブログ]
                externalUrl: "https://hudsonmcnamara.com"
                weight: 94
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

