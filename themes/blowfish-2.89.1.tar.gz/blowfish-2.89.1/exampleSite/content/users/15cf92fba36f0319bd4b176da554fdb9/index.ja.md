---
                title: "Adam Madej - Gameplay Animator"
                tags: [ポートフォリオサイト, ブログ, パーソナルサイト]
                externalUrl: "http://www.adammadej.com/"
                weight: 64
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

