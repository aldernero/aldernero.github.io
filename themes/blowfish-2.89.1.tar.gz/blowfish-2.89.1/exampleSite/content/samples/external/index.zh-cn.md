---
title: "外部文章"
date: 2019-01-24
externalUrl: "https://n9o.xyz/projects/"
summary: "`externalUrl` front matter 参数可以链接到任何外部 URL."
showReadingTime: true
build:
  render: "false"
  list: "local"
type: 'sample'
---

此页面使用 `externalUrl` front matter 参数链接到 Hugo 网站之外的文章。

它非常适合链接到 Medium 上的帖子或在第三方网站上托管的文章。