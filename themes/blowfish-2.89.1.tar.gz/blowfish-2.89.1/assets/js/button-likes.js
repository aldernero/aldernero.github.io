document.getElementById("button_likes") &&
  document.getElementById("button_likes").addEventListener("click", () => {
    process_article();
  });
